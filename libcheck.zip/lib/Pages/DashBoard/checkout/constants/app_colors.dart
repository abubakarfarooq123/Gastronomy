

import 'package:flutter/material.dart';

Color appRedColor = const Color(0xFFE14942);
Color appDimYellow = const Color(0xFFFDF5EF);
Color appLightGrey =  Colors.grey.withOpacity(0.1);