import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:reserved4u/Pages/Profile/reviews/user_review.dart';

import '../../../../Helper/NotificatiokKeys.dart';

class BookingCard extends StatelessWidget {
  BookingCard({Key key, this.index}) : super(key: key);
  final int index;

  final TextStyle stylegrey = TextStyle(
    color: Color(
      AppColor.greytextColor,
    ),
    fontSize: 12,
  );
  final TextStyle heading = TextStyle(
      color: Color(
        AppColor.black,
      ),
      fontSize: 14,
      fontFamily: AppFont.medium);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: 0, left: 0, top: 10),
      child: Container(
        width: 344,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(width: 1, color: const Color(0xFFDADADA)),
        ),
        child: Stack(
          children: [
            Column(
              children: [
                Container(
                  color: const Color(0xFFF9F9FB),
                  child: Row(children: [
                    Container(
                      height: 93,
                      width: 129,
                      decoration: const BoxDecoration(
                          image: DecorationImage(
                              fit: BoxFit.cover,
                              image: AssetImage(
                                  "assets/images/Booking/Rectangle1.png"))),
                    ),
                    Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Text(
                                'Booking ID: ',
                                style: stylegrey,
                              ),

                              Text(
                                '#128394',
                                style: stylegrey.copyWith(color: Colors.black),
                              ),
                              // Image.asset('lib/hart/images/vector2.png'),
                            ],
                          ),
                          SizedBox(
                            height: 3,
                          ),
                          Text(
                            'Chicken Pizza',
                            style: heading,
                          ),
                          SizedBox(
                            height: 3,
                          ),
                          Row(
                            children: [
                              Text('Cheese, canned black beans',
                                  style: stylegrey),
                              // Image.asset('lib/hart/images/vector2.png'),
                            ],
                          )
                        ])
                  ]),
                ),

                SizedBox(
                  height: 10,
                ),

                Container(
                  child: Column(
                    children: [
                      checkIndex(context),
                      Container(
                        margin: const EdgeInsets.all(10),
                        height: 62,
                        // width: 314,
                        decoration: BoxDecoration(
                          color: const Color(0xFFF9F9FB),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Row(
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: Container(
                                height: 52,
                                width: 53,
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10),
                                    image: const DecorationImage(
                                        fit: BoxFit.cover,
                                        image: AssetImage(
                                            'assets/images/Booking/Rectangle13.png'))),
                              ),
                            ),
                            const SizedBox(width: 10),
                            Padding(
                              padding: const EdgeInsets.all(12),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Restaurant name',
                                    style: stylegrey,
                                  ),
                                  SizedBox(height: 3),
                                  Text('SkyKitchen',
                                      style: heading.copyWith(
                                          color: Color(AppColor.red),
                                          fontFamily: AppFont.semiBold))
                                ],
                              ),
                            )
                          ],
                        ),
                        // child:
                      ),
                      // SizedBox(height: 9),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 10.0),
                        child: Container(
                          height: 62,
                          // width: 314,
                          decoration: BoxDecoration(
                            color: const Color(0xFFFDF5EF),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Row(
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: Container(
                                  height: 52,
                                  width: 53,
                                  decoration: BoxDecoration(
                                      color: Color(0xFFE14942),
                                      borderRadius: BorderRadius.circular(12),
                                      image: DecorationImage(
                                          // fit: BoxFit.cover,
                                          image: AssetImage(
                                              'assets/images/Booking/locationinfo.png'))),
                                ),
                              ),
                              const SizedBox(width: 10),
                              Padding(
                                padding: const EdgeInsets.all(5),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Delivery address',
                                      style: heading.copyWith(
                                          fontFamily: AppFont.regular),
                                    ),
                                    // SizedBox(height: 3),
                                    SizedBox(
                                      width: 220,
                                      child: Text(
                                        'Andsberger Allies 65 im andel\'s Hotel Berlin, 12369 Berlin',
                                        style: stylegrey,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                // SizedBox(height: 10),
                Visibility(
                  visible: index == 3 || index == 4,
                  child: GestureDetector(
                    onTap: () {
                      if (index == 4) {
                        _cancellationReason(context);
                      } else {
                        Get.to(UserReview());
                      }
                    },
                    child: Container(
                      margin: const EdgeInsets.all(10),
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      height: 48,
                      // width: 314,
                      decoration: BoxDecoration(
                        color: const Color(0xFFE14942),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Center(
                          child: index == 4
                              ? Text(
                                  'See Cancellation Reason',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 14,
                                      fontFamily: AppFont.medium,
                                      fontWeight: FontWeight.w400),
                                )
                              : Text(
                                  'Share Your Review',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 14,
                                      fontFamily: AppFont.medium,
                                      fontWeight: FontWeight.w400),
                                )),
                    ),
                  ),
                ),
                const SizedBox(height: 10),
              ],
            ),
            Positioned(
              right: 0,
              child: Container(
                  height: 19,
                  width: 32,
                  decoration: const BoxDecoration(
                    color: Color(0xFFE14942),
                    borderRadius: BorderRadius.only(
                        topRight: Radius.circular(9.0),
                        bottomLeft: Radius.circular(9.5)),
                  ),
                  child: const Center(
                    child: Text('1',
                        style: TextStyle(
                          fontWeight: FontWeight.w400,
                          fontSize: 12,
                          color: Colors.white,
                        )),
                  )),
            ),
          ],
        ),
      ),
    );
  }

  Widget checkIndex(context) {
    if (index == 1) {
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Delivery Time',
                  style: stylegrey,
                ),
                Text(
                  '45 Min',
                  style: heading,
                ),
              ],
            ),
            SizedBox(
              height: 3,
            ),
            Column(
              children: [
                Text('Cancel', style: stylegrey),
                Text('    50.00 #',
                    style: heading.copyWith(color: Color(AppColor.red))),
              ],
            ),
            Container(
              height: 35,
              width: 98,
              decoration: BoxDecoration(
                color: const Color(0xFFE14942),
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Center(
                  child: Text(
                'Book Again',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.w400),
              )),
            ),
          ],
        ),
      );
    } else if (index == 2) {
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Delivery Time',
                  style: stylegrey,
                ),
                Text(
                  '45 Min',
                  style: heading,
                ),
              ],
            ),
            SizedBox(
              height: 3,
            ),
            Column(
              children: [
                Text('Booked', style: stylegrey),
                Text('    50.00 #',
                    style: heading.copyWith(color: Color(AppColor.red))),
              ],
            ),
            InkWell(
              onTap: () {
                _bottomSheetPopUp2(context);
              },
              child: Container(
                height: 35,
                width: 98,
                decoration: BoxDecoration(
                  color: const Color(0xFFE14942),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Center(
                    child: Text(
                  'Track',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.w400),
                )),
              ),
            ),
          ],
        ),
      );
    } else if (index == 3) {
      return Padding(
        padding: const EdgeInsets.all(8.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Column(
              children: [
                Icon(Icons.check_circle_outline_outlined, color: Colors.green),
                Text(
                  'Delivered',
                  style: stylegrey,
                ),
              ],
            ),
            SizedBox(
              height: 3,
            ),
            Column(
              children: [
                Text('Completed', style: stylegrey),
                Text('    50.00 #',
                    style: heading.copyWith(color: Color(AppColor.red))),
              ],
            ),
            Container(
              height: 35,
              width: 98,
              decoration: BoxDecoration(
                color: const Color(0xFFE14942),
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Center(
                  child: Text(
                'Book Again',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                    fontWeight: FontWeight.w400),
              )),
            ),
          ],
        ),
      );
    }

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        Column(
          children: [
            Icon(Icons.cancel_outlined, color: Color(AppColor.red)),
            Text(
              'Cancelled',
              style: stylegrey,
            )
          ],
        ),
        SizedBox(
          height: 3,
        ),
        Column(
          children: [
            Text('Cancel', style: stylegrey),
            Text('    50.00 #',
                style: heading.copyWith(color: Color(AppColor.red))),
          ],
        ),
        Container(
          height: 35,
          width: 98,
          decoration: BoxDecoration(
            color: const Color(0xFFE14942),
            borderRadius: BorderRadius.circular(8),
          ),
          child: const Center(
              child: Text(
            'Book Again',
            style: TextStyle(
                color: Colors.white, fontSize: 12, fontWeight: FontWeight.w400),
          )),
        ),
      ],
    );
  }

  Future<dynamic> _bottomSheetPopUp2(context) {
    return showModalBottomSheet<dynamic>(
        // clipBehavior: BorderRadius.only(topLeft: Radius(20),),
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(20.0), topRight: Radius.circular(20.0)),
        ),
        isScrollControlled: true,
        context: context,
        builder: (BuildContext bc) {
          return SizedBox(
            height: 770,
            child: Column(
              children: [
                Stack(children: [
                  Container(
                    height: 202,
                    width: double.maxFinite,
                    decoration: const BoxDecoration(
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(20.0),
                            topRight: Radius.circular(20.0)),
                        image: DecorationImage(
                            fit: BoxFit.cover,
                            image: AssetImage(
                                'assets/images/Booking/Rectangle22.png'))),
                  ),
                  Positioned(
                      right: 20,
                      top: 15,
                      child: InkWell(
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: Container(
                            height: 32,
                            width: 32,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(16),
                              color: const Color(0xffC4C4C4),
                            ),
                            child: const Icon(
                              Icons.close,
                            )),
                      )),
                  Positioned(
                    bottom: 10,
                    right: 40,
                    child: Container(
                      height: 52,
                      width: 332,
                      decoration: BoxDecoration(
                        color: const Color(0xFFEDEDEA).withOpacity(0.7),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(
                              left: 10,
                              top: 8,
                            ),
                            child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: const [
                                  Text('Distance'),
                                  Text('3 km',
                                      style: TextStyle(
                                        fontWeight: FontWeight.w600,
                                        fontSize: 18,
                                        color: Color(0xffE14942),
                                      ))
                                ]),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(
                              right: 45,
                              top: 5,
                            ),
                            child: Row(
                              children: const [
                                Text('Your Food is ',
                                    style: TextStyle(
                                      fontWeight: FontWeight.w400,
                                      fontSize: 12,
                                    )),
                                Text('18 min ',
                                    style: TextStyle(
                                      fontWeight: FontWeight.w600,
                                      fontSize: 16,
                                      color: Color(0xffE14942),
                                    )),
                                Text('away',
                                    style: TextStyle(
                                      fontWeight: FontWeight.w400,
                                      fontSize: 12,
                                    )),
                              ],
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ]),
                Expanded(
                    child: Column(
                  children: [
                    Container(
                        margin:
                            const EdgeInsets.only(top: 16, right: 20, left: 20),
                        height: 64,
                        child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.only(
                                          top: 8.0, bottom: 8.0),
                                      child: Row(
                                        children: const [
                                          Text(
                                            'Booking ID:',
                                            style: TextStyle(
                                                fontSize: 20,
                                                fontWeight: FontWeight.w400,
                                                color: Colors.grey),
                                          ),
                                          SizedBox(width: 3),
                                          Text(
                                            '#123456',
                                            style: TextStyle(
                                              fontSize: 20,
                                              fontWeight: FontWeight.w600,
                                              color: Colors.black,
                                            ),
                                          )
                                        ],
                                      ),
                                    ),
                                    const Text(
                                      'Chicken Pizza',
                                      style: TextStyle(
                                        fontSize: 14,
                                        fontWeight: FontWeight.w400,
                                        color: Colors.black,
                                      ),
                                    ),
                                  ]),
                              const Padding(
                                padding: EdgeInsets.only(top: 3),
                                child: Text(
                                  '12.00€',
                                  style: TextStyle(
                                      fontSize: 22,
                                      fontWeight: FontWeight.w600,
                                      color: Color(0xffE14942)),
                                ),
                              )
                            ])),
                    const Divider(height: 4),
                    Container(
                      child: Stack(children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Column(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  height: 89,
                                  width: 110,
                                  decoration: BoxDecoration(
                                    color: const Color(0xffE14942),
                                    borderRadius: BorderRadius.circular(10),
                                    image: const DecorationImage(
                                        fit: BoxFit.cover,
                                        image: AssetImage(
                                            'assets/images/Booking/Rectangle(1).png')),
                                  ),
                                ),
                                const SizedBox(height: 5),
                                const Text('Fatija Pizza'),
                              ],
                            ),
                            Column(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  height: 89,
                                  width: 110,
                                  decoration: BoxDecoration(
                                    color: const Color(0xffE14942),
                                    borderRadius: BorderRadius.circular(10),
                                    image: const DecorationImage(
                                        fit: BoxFit.cover,
                                        image: AssetImage(
                                            'assets/images/Booking/Rectangle(2).png')),
                                  ),
                                ),
                                const SizedBox(height: 5),
                                const Text('Veg Pizza'),
                              ],
                            ),
                            Column(
                              children: [
                                Container(
                                  height: 89,
                                  width: 110,
                                  decoration: BoxDecoration(
                                    color: const Color(0xffE14942),
                                    borderRadius: BorderRadius.circular(10),
                                    image: const DecorationImage(
                                        fit: BoxFit.cover,
                                        image: AssetImage(
                                            'assets/images/Booking/Rectangle(3).png')),
                                  ),
                                ),
                                Container(
                                  height: 20,
                                ),
                              ],
                            ),
                          ],
                        ),
                        Positioned(
                          right: 20,
                          child: Container(
                            height: 89,
                            width: 110,
                            decoration: BoxDecoration(
                              color: Colors.grey.withOpacity(0.8),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: const Center(
                              child: Text('+3 items',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w600,
                                    fontSize: 22,
                                    color: Colors.white,
                                  )),
                            ),
                          ),
                        ),
                      ]),
                    ),
                    Container(
                        margin:
                            const EdgeInsets.only(top: 10, right: 20, left: 20),
                        height: 64,
                        child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: const [
                                    Text(
                                      'Track Your Order',
                                      style: TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.w500,
                                        color: Colors.black,
                                      ),
                                    ),
                                    Padding(
                                        padding:
                                            EdgeInsets.only(top: 4, bottom: 4),
                                        child: Text(
                                          'Order Status:',
                                          style: TextStyle(
                                              fontSize: 14,
                                              fontWeight: FontWeight.w500,
                                              color: Color(0xff455A64)),
                                        ))
                                  ]),
                              Container(
                                height: 35,
                                width: 116,
                                decoration: BoxDecoration(
                                  color: const Color(0xFFE14942),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Image.asset(
                                        'assets/images/Booking/Vector4.png'),
                                    const SizedBox(width: 5),
                                    const Text(
                                      'Live Tracking',
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 12,
                                          fontWeight: FontWeight.w400),
                                    ),
                                  ],
                                ),
                              ),
                            ])),
                    Container(
                        margin: const EdgeInsets.only(left: 30),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(right: 15.0),
                              child: Column(
                                // mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                children: [
                                  const SizedBox(height: 27),
                                  Container(
                                    height: 16,
                                    width: 16,
                                    decoration: BoxDecoration(
                                      color: const Color(0xffE14942),
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: const Center(
                                        child: Icon(Icons.done,
                                            size: 7.0, color: Colors.white)),
                                  ),
                                  Container(
                                    height: 57,
                                    width: 1,
                                    color: const Color(0xffE14942),
                                  ),
                                  Container(
                                    height: 16,
                                    width: 16,
                                    decoration: BoxDecoration(
                                      color: const Color(0xffE14942),
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: const Center(
                                        child: Icon(Icons.done,
                                            size: 7.0, color: Colors.white)),
                                  ),
                                  Container(
                                    height: 57,
                                    width: 1,
                                    color: const Color(0xffE14942),
                                  ),
                                  Container(
                                    height: 16,
                                    width: 16,
                                    decoration: BoxDecoration(
                                      color: const Color(0xffE14942),
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: const Center(
                                        child: Icon(Icons.done,
                                            size: 7.0, color: Colors.white)),
                                  ),
                                  Container(
                                    height: 57,
                                    width: 1,
                                    color: const Color(0xff7B7E86),
                                  ),
                                  Container(
                                    height: 16,
                                    width: 16,
                                    decoration: BoxDecoration(
                                      border: Border.all(
                                        color: const Color(0xff9E9E9E),
                                      ),
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Column(
                              children: [
                                Padding(
                                  padding: const EdgeInsets.all(5),
                                  child: Container(
                                    // margin: EdgeInsets.all(10),
                                    height: 62,
                                    width: 314,
                                    decoration: BoxDecoration(
                                      color: const Color(0xFFFDF5EF),
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    child: Row(
                                      children: [
                                        Container(
                                          padding: EdgeInsets.symmetric(
                                              vertical: 10, horizontal: 5),
                                          height: 52,
                                          width: 53,
                                          decoration: BoxDecoration(
                                            color: const Color(0xffE14942),
                                            borderRadius:
                                                BorderRadius.circular(10),
                                          ),
                                          child: SvgPicture.asset(
                                              "assets/images/Booking/orderplaced.svg"),
                                        ),
                                        // SizedBox(width: 10),
                                        Padding(
                                          padding: const EdgeInsets.only(
                                              top: 15, bottom: 15, left: 25),
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: const [
                                              Text(
                                                'Order Placed',
                                                style: TextStyle(
                                                    fontSize: 12,
                                                    fontWeight: FontWeight.w400,
                                                    color: Colors.black),
                                              ),
                                              SizedBox(height: 2),
                                              Text(
                                                '12:30 AM',
                                                style: TextStyle(
                                                    fontSize: 10,
                                                    fontWeight: FontWeight.w400,
                                                    color: Color(0xff7B7E86)),
                                              )
                                            ],
                                          ),
                                        )
                                      ],
                                    ),
                                    // child:
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(5),
                                  child: Container(
                                    // margin: EdgeInsets.all(10),
                                    height: 62,
                                    width: 314,
                                    decoration: BoxDecoration(
                                      color: const Color(0xFFFDF5EF),
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    child: Row(
                                      children: [
                                        Container(
                                          padding: EdgeInsets.symmetric(
                                              vertical: 10, horizontal: 5),
                                          height: 52,
                                          width: 53,
                                          decoration: BoxDecoration(
                                            color: const Color(0xffE14942),
                                            borderRadius:
                                                BorderRadius.circular(10),
                                          ),
                                          child: SvgPicture.asset(
                                              "assets/images/Booking/orderconfirm.svg"),
                                        ),
                                        // SizedBox(width: 10),
                                        Padding(
                                          padding: const EdgeInsets.only(
                                              top: 15, bottom: 15, left: 25),
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: const [
                                              Text(
                                                'Order Confirmed',
                                                style: TextStyle(
                                                    fontSize: 12,
                                                    fontWeight: FontWeight.w400,
                                                    color: Colors.black),
                                              ),
                                              SizedBox(height: 2),
                                              Text(
                                                'Your Order Has been Confirmed',
                                                style: TextStyle(
                                                    fontSize: 10,
                                                    fontWeight: FontWeight.w400,
                                                    color: Color(0xff7B7E86)),
                                              )
                                            ],
                                          ),
                                        )
                                      ],
                                    ),
                                    // child:
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(5),
                                  child: Container(
                                    // margin: EdgeInsets.all(10),
                                    height: 62,
                                    width: 314,
                                    decoration: BoxDecoration(
                                      color: const Color(0xFFFDF5EF),
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    child: Row(
                                      children: [
                                        Container(
                                          padding: EdgeInsets.symmetric(
                                              vertical: 10, horizontal: 5),
                                          height: 52,
                                          width: 53,
                                          decoration: BoxDecoration(
                                            color: const Color(0xffE14942),
                                            borderRadius:
                                                BorderRadius.circular(10),
                                          ),
                                          child: SvgPicture.asset(
                                              "assets/images/Booking/orderprocessd.svg"),
                                        ),
                                        // SizedBox(width: 10),
                                        Padding(
                                          padding: const EdgeInsets.only(
                                              top: 15, bottom: 15, left: 25),
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: const [
                                              Text(
                                                'Order Processed',
                                                style: TextStyle(
                                                    fontSize: 12,
                                                    fontWeight: FontWeight.w400,
                                                    color: Colors.black),
                                              ),
                                              SizedBox(height: 2),
                                              Text(
                                                'We are Preparing Your Order',
                                                style: TextStyle(
                                                    fontSize: 10,
                                                    fontWeight: FontWeight.w400,
                                                    color: Color(0xff7B7E86)),
                                              )
                                            ],
                                          ),
                                        )
                                      ],
                                    ),
                                    // child:
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(5),
                                  child: Container(
                                    // margin: EdgeInsets.all(10),
                                    height: 62,
                                    width: 314,
                                    decoration: BoxDecoration(
                                      color: Colors.grey.shade200,
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    child: Row(
                                      children: [
                                        Container(
                                          padding: EdgeInsets.symmetric(
                                              vertical: 10, horizontal: 5),
                                          height: 52,
                                          width: 53,
                                          decoration: BoxDecoration(
                                            color: Color(0xffDADADA)
                                                .withOpacity(1),
                                            borderRadius:
                                                BorderRadius.circular(10),
                                          ),
                                          child: SvgPicture.asset(
                                              "assets/images/Booking/scoter.svg"),
                                        ),
                                        // SizedBox(width: 10),
                                        Padding(
                                          padding: const EdgeInsets.only(
                                              top: 15, bottom: 15, left: 25),
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: const [
                                              Text(
                                                'Order Placed',
                                                style: TextStyle(
                                                    fontSize: 12,
                                                    fontWeight: FontWeight.w400,
                                                    color: Colors.black),
                                              ),
                                              SizedBox(height: 2),
                                              Text(
                                                '12:30 AM',
                                                style: TextStyle(
                                                    fontSize: 10,
                                                    fontWeight: FontWeight.w400,
                                                    color: Color(0xff7B7E86)),
                                              )
                                            ],
                                          ),
                                        )
                                      ],
                                    ),
                                    // child:
                                  ),
                                ),
                              ],
                            )
                          ],
                        ))
                  ],
                )),
              ],
            ),
          );
        });
  }

  Future<dynamic> _cancellationReason(context) {
    return showModalBottomSheet<dynamic>(

        // clipBehavior: BorderRadius.only(topLeft: Radius(20),),

        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(20.0), topRight: Radius.circular(20.0)),
        ),
        isScrollControlled: true,
        context: context,
        builder: (BuildContext bc) {
          return SizedBox(
            height: 500,
            child: Column(
              children: [
                Container(
                  margin: EdgeInsets.symmetric(vertical: 15),
                  child: Text(
                    "Reason For Cancellation",
                    style: TextStyle(
                        color: Colors.black,
                        fontFamily: AppFont.bold,
                        fontSize: 20),
                  ),
                ),
                Container(
                  height: 150,
                  width: double.maxFinite,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      image: DecorationImage(
                          fit: BoxFit.cover,
                          image: AssetImage(
                              'assets/images/Booking/Rectangle22.png'))),
                ),
                Expanded(
                    child: Column(
                  children: [
                    Container(
                        margin:
                            const EdgeInsets.only(top: 16, right: 20, left: 20),
                        height: 64,
                        child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.only(
                                          top: 8.0, bottom: 8.0),
                                      child: Row(
                                        children: [
                                          SizedBox(width: 3),
                                          Text(
                                            "Marv's Pizza",
                                            style: TextStyle(
                                              fontSize: 20,
                                              fontFamily: AppFont.semiBold,
                                              fontWeight: FontWeight.w600,
                                              color: Colors.black,
                                            ),
                                          )
                                        ],
                                      ),
                                    ),
                                    Row(
                                      children: [
                                        const Text(
                                          'Booking ID :',
                                          style: TextStyle(
                                            fontSize: 14,
                                            fontWeight: FontWeight.w400,
                                            color: Colors.grey,
                                          ),
                                        ),
                                        Text(
                                          '#123456',
                                          style: TextStyle(
                                              fontSize: 14,
                                              fontWeight: FontWeight.w400,
                                              color: Colors.black,
                                              fontFamily: AppFont.regular),
                                        ),
                                      ],
                                    ),
                                  ]),
                              Padding(
                                padding: EdgeInsets.only(top: 3),
                                child: Text(
                                  '50.00€',
                                  style: TextStyle(
                                      fontSize: 22,
                                      fontFamily: AppFont.bold,
                                      fontWeight: FontWeight.w600,
                                      color: Color(0xffE14942)),
                                ),
                              )
                            ])),
                    const Divider(height: 4),
                    Container(
                      margin: EdgeInsets.only(left: 20, top: 20),
                      alignment: Alignment.centerLeft,
                      child: Text(
                        "I Cancelled the booking Because",
                        style: TextStyle(
                            fontSize: 16,
                            fontFamily: AppFont.bold,
                            fontWeight: FontWeight.w600,
                            color: Color(AppColor.black)),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.only(left: 20, top: 10),
                      alignment: Alignment.centerLeft,
                      child: Text(
                        "lorem ispern the text helo sit amet adpicong elit sed do eiosd temop imcdidunt ut labire et dikire anga aliqua Quis ipsum sispendidse tcces ",
                        style: TextStyle(
                            fontSize: 16,
                            fontFamily: AppFont.regular,
                            color: Color(AppColor.greytextColor)),
                      ),
                    )
                  ],
                )),
              ],
            ),
          );
        });
  }

}
