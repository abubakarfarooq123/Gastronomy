
class ResturantReviewModel {
  String allOverAvg;
  int totalFeedBack;
  List<TotalAvgRating> totalAvgRating;
  List<Null> customerReview;

  ResturantReviewModel(
      {this.allOverAvg,
        this.totalFeedBack,
        this.totalAvgRating,
        this.customerReview});

  ResturantReviewModel.fromJson(Map<String, dynamic> json) {
    allOverAvg = json['allOverAvg'];
    totalFeedBack = json['totalFeedBack'];
    if (json['totalAvgRating'] != null) {
      totalAvgRating = <TotalAvgRating>[];
      json['totalAvgRating'].forEach((v) {
        totalAvgRating.add(new TotalAvgRating.fromJson(v));
      });
    }
    if (json['customerReview'] != null) {
      customerReview = <Null>[];
      // json['customerReview'].forEach((v) {
      //   customerReview.add(new Null.fromJson(v));
      // });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['allOverAvg'] = this.allOverAvg;
    data['totalFeedBack'] = this.totalFeedBack;
    if (this.totalAvgRating != null) {
      data['totalAvgRating'] =
          this.totalAvgRating.map((v) => v.toJson()).toList();
    }
    // if (this.customerReview != null) {
    //   data['customerReview'] =
    //       this.customerReview.map((v) => v.toJson()).toList();
    // }
    return data;
  }
}

class TotalAvgRating {
  String foodRate;
  String deliveryRate;

  TotalAvgRating({this.foodRate, this.deliveryRate});

  TotalAvgRating.fromJson(Map<String, dynamic> json) {
    foodRate = json['food_rate'];
    deliveryRate = json['delivery_rate'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['food_rate'] = this.foodRate;
    data['delivery_rate'] = this.deliveryRate;
    return data;
  }
}
