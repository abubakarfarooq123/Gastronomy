import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:reserved4u/Pages/Profile/Bookings/widgets/booking_card.dart';

import '../../../Helper/NotificatiokKeys.dart';
import '../../Favourite/FavouriteCell.dart';

class Bookings extends StatefulWidget {
  const Bookings({Key key}) : super(key: key);

  @override
  State<Bookings> createState() => _BookingsState();
}

class _BookingsState extends State<Bookings> with TickerProviderStateMixin {
  @override
  Widget build(BuildContext context) {
    TabController _tabController = TabController(length: 4, vsync: this);

    return Scaffold(
        appBar: AppBar(
          systemOverlayStyle: SystemUiOverlayStyle(
            // Status bar color
            statusBarColor: Colors.white,

            // Status bar brightness (optional)
          ),
          toolbarHeight: 0,
          elevation: 0,
        ),
        backgroundColor: Colors.white,
        body: Stack(
          children: [
            Column(children: [
              Expanded(
                child: Container(
                    margin: EdgeInsets.only(top: 210),
                    height: Get.height * 0.68,
                    width: double.maxFinite,
                    padding: const EdgeInsets.all(15),
                    child: Column(
                      children: [
                        Center(
                          child: TabBar(
                            padding: EdgeInsets.only(bottom: 0),
                            isScrollable: true,
                            controller: _tabController,
                            labelColor: const Color(0xffE14942),
                            indicatorColor: const Color(0xffE14942),
                            unselectedLabelColor: const Color(0xff9E9E9E),
                            tabs: const [
                              Tab(
                                child: Text('Pending'),
                              ),
                              Tab(
                                child: Text(
                                  'Running',
                                  style: TextStyle(),
                                ),
                              ),
                              Tab(
                                child: Text(
                                  'Completed',
                                  style: TextStyle(),
                                ),
                              ),
                              Tab(
                                child: Text(
                                  'Cancelled',
                                  style: TextStyle(),
                                ),
                              ),
                            ],
                          ),
                        ),

                        Expanded(
                          child: SizedBox(
                            width: double.maxFinite,
                            // height: double.maxFinite,
                            child: TabBarView(
                              controller: _tabController,
                              children: [
                                MediaQuery.removePadding(
                                  context: context,
                                  removeTop: true,
                                  child: ListView(children: [
                                    BookingCard(
                                      index: 1,
                                    ),
                                    BookingCard(index: 1),
                                    BookingCard(index: 1),
                                  ]),
                                ),
                                MediaQuery.removePadding(
                                  context: context,
                                  removeTop: true,
                                  child: ListView(
                                      shrinkWrap: false,
                                      primary: true,
                                      children: [
                                        BookingCard(
                                          index: 2,
                                        ),
                                        BookingCard(index: 2),
                                        BookingCard(index: 2),
                                      ]),
                                ),
                                MediaQuery.removePadding(
                                  context: context,
                                  removeTop: true,
                                  child: ListView(
                                      shrinkWrap: true,
                                      primary: false,
                                      children: [
                                        BookingCard(index: 3),
                                        BookingCard(index: 3),
                                        BookingCard(index: 3),
                                      ]),
                                ),
                                MediaQuery.removePadding(
                                  context: context,
                                  removeTop: true,
                                  child: ListView(
                                      shrinkWrap: true,
                                      primary: false,
                                      children: [
                                        BookingCard(
                                          index: 4,
                                        ),
                                        BookingCard(index: 4),
                                        BookingCard(index: 4),
                                      ]),
                                ),

                                // Container(),

                                // Container(),
                              ],
                            ),
                          ),
                        ),
                        // Divider(
                        //   thickness: 1,
                        // ),
                      ],
                    )),
              )
            ]),
            headerRow(),
            Positioned(
              top: 205,
              left: Get.width * 0.22,
              child: Container(
                width: 25,
                height: 25,
                decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.red, width: 8)),
              ),
            ),
            Positioned(
              top: 205,
              left: Get.width * 0.69,
              child: Container(
                width: 25,
                height: 25,
                decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.grey, width: 2)),
              ),
            ),
          ],
        ));
  }

  Widget headerRow() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: Row(children: [
            Material(
              elevation: 3,
              color: Colors.white,
              borderRadius: BorderRadius.circular(30),
              child: Ink(
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(30)),
                child: IconButton(
                  color: Colors.black,

                  onPressed: () {
                    Get.back();
                  },
                  icon: const Icon(
                    Icons.arrow_back_ios,
                    size: 20,
                  ),

                  // onPressed: (){},
                ),
              ),
            ),
            // SizedBox(width: 82),
            const Spacer(),
            const Text(
              'My Bookings',
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18),
            ),
            const Spacer(),
            // SizedBox(width: 41),
            Material(
              elevation: 3,
              borderRadius: BorderRadius.circular(30),
              child: InkWell(
                onTap: () {},
                child: Ink(
                  padding: EdgeInsets.all(0),
                  decoration: BoxDecoration(
                      color: Colors.white, shape: BoxShape.circle),
                  child: Padding(
                    padding: const EdgeInsets.all(12.0),
                    child: SvgPicture.asset(
                      "assets/images/Booking/calender.svg",
                      height: 25,
                      width: 25,
                      color: Color(0xff455A64),
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 10),
            Ink(
              decoration: BoxDecoration(
                  color: const Color(0xffE14942), shape: BoxShape.circle),
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: SvgPicture.asset(
                  "assets/images/Booking/filter.svg",
                  height: 25,
                  width: 25,
                  // color: Color(0xff000000),
                ),
              ),
            ),
          ]),
        ),
        Container(
          color: Color(AppColor.lightpink),
          height: 140,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Container(
                  alignment: Alignment.topCenter,
                  child: Image.asset(
                    AssestPath.favourite + "fav1.png",
                    width: 110,
                    height: 150,
                  )),
              // Container(
              //   height: 100,
              //   width: 2,
              //   color: Colors.red,
              // ),
              Container(
                height: 100,
                width: 2,
                decoration: BoxDecoration(
                    gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                      Color(AppColor.red).withOpacity(0.1),
                      Color(AppColor.red),
                      Color(AppColor.red).withOpacity(0.1)
                    ])),
              ),
              Container(
                  // foregroundDecoration: BoxDecoration(
                  //   color: Colors.grey,
                  //   backgroundBlendMode: BlendMode.saturation,
                  // ),
                  // decoration: BoxDecoration(color: Color(AppColor.lightpink)),
                  // alignment: Alignment.topCenter,
                  // color: Colors.red,
                  child: Padding(
                padding: const EdgeInsets.only(bottom: 20),
                child: Image.asset(
                  AssestPath.favourite + "fav2_bw.png",
                  width: 130,
                  height: 90,
                ),
              )),
            ],
          ),
        ),
      ],
    );
  }
}
