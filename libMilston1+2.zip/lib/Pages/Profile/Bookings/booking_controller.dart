

import 'package:get/get.dart';

class BookingControllers extends GetxController{





}