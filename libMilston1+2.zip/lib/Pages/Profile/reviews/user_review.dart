import 'package:flutter/material.dart';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:reserved4u/Helper/NotificatiokKeys.dart';
import 'package:reserved4u/Pages/DashBoard/checkout/widgets/address_input.dart';
import 'package:reserved4u/Pages/DashBoard/checkout/widgets/custom_button.dart';
import 'package:reserved4u/Pages/Profile/Setting/SettingController.dart';

// ignore: must_be_immutable
class UserReview extends StatelessWidget {
  SettingController _settingController = Get.put(SettingController());
  @override
  Widget build(BuildContext context) {
    return Container(
      height: Get.height,
      width: Get.width,
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        // bottomNavigationBar: changePasswowrdBottom(),
        backgroundColor: Color(AppColor.bgColor),
        appBar: AppBar(
          systemOverlayStyle:
              SystemUiOverlayStyle(statusBarColor: Colors.white),
          backgroundColor: Color(AppColor.bgColor),
          elevation: 1,
          centerTitle: true,
          title: Image.asset(
            "assets/images/Login/Logo_Home.png",
            width: 100,
            height: 35,
          ),
          leading: Padding(
            padding: const EdgeInsets.fromLTRB(12, 2, 0, 12),
            child: Container(
                height: 20,
                width: 20,
                decoration: BoxDecoration(
                    boxShadow: [
                      const BoxShadow(
                          color: Colors.black12,
                          spreadRadius: 1,
                          offset: Offset(1, 1),
                          blurRadius: 7)
                    ],
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(100)),
                child: IconButton(
                  icon: Icon(
                    Icons.arrow_back_ios_outlined,
                    color: Colors.black,
                  ),
                  onPressed: () {
                    Get.back();
                  },
                  iconSize: 20,
                )),
          ),
        ),
        body: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              SizedBox(
                height: 20,
              ),
              SizedBox(
                width: 100,
                height: 100,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(100),
                  child: CircleAvatar(
                    child: Image.network(
                      "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
                      width: 100,
                      height: 100,
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Text(
                "Share your experiences with other users",
                style: TextStyle(fontFamily: AppFont.regular, fontSize: 16),
              ),
              SizedBox(
                height: 20,
              ),
              Text(
                "SKy Kitchen",
                style: TextStyle(
                    fontFamily: AppFont.bold,
                    fontSize: 18,
                    color: Color(AppColor.red)),
              ),
              SizedBox(
                height: 20,
              ),
              GestureDetector(
                onTap: () {
                  dialouge(context);
                },
                child: Container(
                  margin: EdgeInsets.symmetric(horizontal: 30),
                  padding: EdgeInsets.symmetric(horizontal: 10),
                  height: 45,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.grey, width: 1)),
                  child: Row(
                    children: [
                      SvgPicture.asset(
                        AssestPath.favourite + 'for.svg',
                        color: Colors.grey,
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      Text("Choose Items")
                    ],
                  ),
                ),
              ),
              // dialouge()
              SizedBox(
                height: 20,
              ),
              Padding(
                padding: const EdgeInsets.only(left: 18),
                child: Text('Food'.tr,
                    style:
                        TextStyle(fontSize: 18, fontFamily: AppFont.semiBold)),
              ),
              SizedBox(height: 5),
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: Color(AppColor.lightpink),
                ),
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                child: RatingBar.builder(
                  initialRating: 2,
                  minRating: 0,
                  direction: Axis.horizontal,
                  allowHalfRating: true,
                  glowColor: Colors.white,
                  itemSize: 40,
                  unratedColor: Color(0xFFdadbde),
                  itemPadding: EdgeInsets.symmetric(horizontal: 0.0),
                  itemBuilder: (context, index) {
                    return Container(
                      height: 30,
                      width: 45,
                      child: Image.asset(
                        AssestPath.homeView + "Star.png",
                        height: 18,
                        width: 18,
                      ),
                    );
                  },
                  onRatingUpdate: (value) {
                    value + 1;
                  },
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Padding(
                padding: const EdgeInsets.only(left: 18),
                child: Text('Delivery'.tr,
                    style:
                        TextStyle(fontSize: 18, fontFamily: AppFont.semiBold)),
              ),
              SizedBox(height: 5),
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: Color(AppColor.lightpink),
                ),
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                child: RatingBar.builder(
                  initialRating: 2,
                  minRating: 0,
                  direction: Axis.horizontal,
                  allowHalfRating: true,
                  glowColor: Colors.white,
                  itemSize: 40,
                  unratedColor: Color(0xFFdadbde),
                  itemPadding: EdgeInsets.symmetric(horizontal: 0.0),
                  itemBuilder: (context, index) {
                    return Container(
                      height: 30,
                      width: 45,
                      child: Image.asset(
                        AssestPath.homeView + "Star.png",
                        height: 18,
                        width: 18,
                      ),
                    );
                  },
                  onRatingUpdate: (value) {
                    value + 1;
                  },
                ),
              ),

              SizedBox(
                height: 30,
              ),

              Container(
                  margin: EdgeInsets.symmetric(horizontal: 30),
                  child: AddressInput(hintText: "Share Your Experience here ")),

              SizedBox(height: 30,),

              SizedBox(
                width: 300,
                child: CustomButton(
                  title: "Send FeedBack",onPressed: (){},
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  Future<Widget> dialouge(context) async {
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return Dialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                // border: Border.all(color: Colors.grey, width: 1)),
              ),
              height: 410,
              child: Column(
                children: [
                  Container(
                    margin: EdgeInsets.symmetric(horizontal: 0),
                    padding: EdgeInsets.symmetric(horizontal: 10),
                    height: 45,
                    decoration: BoxDecoration(
                      color: Colors.red.withOpacity(0.2),

                      borderRadius: BorderRadius.circular(12),
                      // border: Border.all(color: Colors.grey, width: 1)),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "Select Items",
                          style: TextStyle(
                              color: Colors.red,
                              fontFamily: AppFont.semiBold,
                              fontSize: 16),
                        ),
                        Icon(
                          Icons.cancel,
                          color: Colors.red,
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Container(
                    margin: EdgeInsets.symmetric(horizontal: 15),
                    child: SizedBox(
                      height: 40,
                      child: Material(
                        color: Colors.white,
                        elevation: 2,
                        borderRadius: BorderRadius.circular(12),
                        child: TextFormField(
                          decoration: InputDecoration(
                              border: InputBorder.none,
                              disabledBorder: InputBorder.none,
                              enabledBorder: InputBorder.none,
                              errorBorder: InputBorder.none,
                              focusedBorder: InputBorder.none,
                              focusedErrorBorder: InputBorder.none,
                              hintText: "search Items",
                              hintStyle: TextStyle(color: Colors.grey),
                              prefixIcon: Icon(
                                Icons.search,
                                color: Colors.grey,
                              )),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      select("Pizza"),
                      select("Snacks"),
                      select("Deserts"),
                      select("Chicken"),
                    ],
                  ),
                  Scrollbar(
                    isAlwaysShown: true,
                    interactive: true,
                    child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: Colors.grey.shade100,
                        ),
                        height: 100,
                        margin:
                            EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                        width: double.infinity,
                        child: ListView(
                          scrollDirection: Axis.vertical,
                          children: [
                            Container(
                                margin: EdgeInsets.symmetric(
                                    vertical: 10, horizontal: 10),
                                child: Text(
                                  "Marvs Pizza ",
                                  style: TextStyle(
                                      color: Colors.grey,
                                      fontFamily: AppFont.medium),
                                )),
                            Container(
                                margin: EdgeInsets.symmetric(
                                    vertical: 10, horizontal: 10),
                                child: Text(
                                  "Marvs Pizza ",
                                  style: TextStyle(
                                      color: Colors.grey,
                                      fontFamily: AppFont.medium),
                                )),
                            Container(
                                margin: EdgeInsets.symmetric(
                                    vertical: 10, horizontal: 10),
                                child: Text(
                                  "Marvs Pizza ",
                                  style: TextStyle(
                                      color: Colors.grey,
                                      fontFamily: AppFont.medium),
                                )),
                            Container(
                                margin: EdgeInsets.symmetric(
                                    vertical: 10, horizontal: 10),
                                child: Text(
                                  "Marvs Pizza ",
                                  style: TextStyle(
                                      color: Colors.grey,
                                      fontFamily: AppFont.medium),
                                )),
                          ],
                        )),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Container(
                      margin: EdgeInsets.symmetric(horizontal: 10),
                      width: double.infinity,
                      height: 40,
                      child: CustomButton(title: "Further", onPressed: () {})),
                  SizedBox(
                    height: 20,
                  ),
                  Text(
                    "Loschen",
                    style: TextStyle(
                        decoration: TextDecoration.underline,
                        color: Colors.red.withOpacity(0.7)),
                  ),
                  SizedBox(
                    height: 15,
                  )
                ],
              ),
            ),
          );
        });
  }

  Widget select(text) {
    return Column(
      children: [
        SizedBox(
          width: 50,
          height: 50,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(100),
            child: CircleAvatar(
              child: Image.network(
                "https://img.freepik.com/free-photo/top-view-pepperoni-pizza-with-mushroom-sausages-bell-pepper-olive-corn-black-wooden_141793-2158.jpg?w=1380&t=st=1659378814~exp=1659379414~hmac=9a52978169c8a464775c4533c0cee4b17002db30614a58117283ccd4be5a4aec",
                width: 100,
                height: 100,
                fit: BoxFit.cover,
              ),
            ),
          ),
        ),
        Text(
          text,
          style: TextStyle(fontFamily: AppFont.semiBold),
        ),
      ],
    );
  }
}
