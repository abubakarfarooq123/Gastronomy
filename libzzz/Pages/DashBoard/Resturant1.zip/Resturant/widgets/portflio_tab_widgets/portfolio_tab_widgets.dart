import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_viewer/image_viewer.dart';
import 'package:reserved4u/Pages/DashBoard/Resturant/resturant_details_model.dart';
import 'package:reserved4u/Pages/DashBoard/Resturant/widgets/portflio_tab_widgets/image_view_page.dart';

import '../../../../../Helper/NotificatiokKeys.dart';
import '../../resturant_detail_controller.dart';

class PortfolioTabWidgets extends StatelessWidget {
  PortfolioTabWidgets({Key key}) : super(key: key);
  ResturantController _storeDetailController = Get.put(ResturantController());

  final List img = [
    'https://images.unsplash.com/photo-1504674900247-0877df9cc836?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxleHBsb3JlLWZlZWR8MXx8fGVufDB8fHx8&auto=format&fit=crop&w=500&q=60',
    'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxleHBsb3JlLWZlZWR8Mnx8fGVufDB8fHx8&auto=format&fit=crop&w=500&q=60',
    'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxleHBsb3JlLWZlZWR8M3x8fGVufDB8fHx8&auto=format&fit=crop&w=500&q=60',
    'https://images.unsplash.com/photo-1567620905732-2d1ec7ab7445?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxleHBsb3JlLWZlZWR8NHx8fGVufDB8fHx8&auto=format&fit=crop&w=500&q=60',
    'https://images.unsplash.com/photo-1565958011703-44f9829ba187?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxleHBsb3JlLWZlZWR8Nnx8fGVufDB8fHx8&auto=format&fit=crop&w=500&q=60',
    'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxleHBsb3JlLWZlZWR8NXx8fGVufDB8fHx8&auto=format&fit=crop&w=500&q=60',
    'https://images.unsplash.com/photo-1482049016688-2d3e1b311543?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxleHBsb3JlLWZlZWR8OXx8fGVufDB8fHx8&auto=format&fit=crop&w=500&q=60',
    'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxleHBsb3JlLWZlZWR8MTB8fHxlbnwwfHx8fA%3D%3D&auto=format&fit=crop&w=500&q=60',
  ];
  final controller = Get.find<ResturantController>();

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;

    return Container(
      margin: EdgeInsets.all(15),
      width: Get.width,
      child:
          _storeDetailController.resturantDetails.value.storeGallery.length == 0
              ? Container(
                  alignment: Alignment.center,
                  child: Text(
                    'noDataFound'.tr,
                    style: TextStyle(
                      fontFamily: AppFont.bold,
                      fontSize: 15,
                    ),
                  ),
                )
              : gridViewForPortfolio(),
    );

    //  Center(
    //   child: Wrap(
    //     crossAxisAlignment: WrapCrossAlignment.center,
    //     runAlignment: WrapAlignment.center,
    //     runSpacing: 10,
    //     spacing: 10,
    //     children: controller.resturantDetails.value.storeGallery.length!=0? List.generate(
    //         controller.resturantDetails.value.storeGallery.length,
    //             (index) => GestureDetector(
    //               onTap: (){
    //                 Get.to(ImageViewPage(imageList:[controller.resturantDetails.value.storeGallery[index].storeGalleryImagePath] ,));
    //               },
    //               child: ClipRRect(
    //           borderRadius: BorderRadius.circular(15),
    //           child: Container(
    //               decoration:
    //               BoxDecoration(borderRadius: BorderRadius.circular(20)),
    //               child: Image.network(
    //                 controller.resturantDetails.value.storeGallery[index].storeGalleryImagePath,
    //                 height: 150,
    //                 width: size.width * 0.4,
    //                 fit: BoxFit.cover,
    //               ),
    //           ),
    //         ),
    //             )):[SizedBox(
    //       child: Text("No Data to Show"),
    //     )],
    //   ),
    // );
  }

  Widget gridViewForPortfolio() {
    return GridView.builder(
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      itemCount:
          _storeDetailController.resturantDetails.value.storeGallery.length,
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 5.0,
        mainAxisSpacing: 5.0,
      ),
      itemBuilder: (BuildContext context, int index) {
        var currentObj =
            _storeDetailController.resturantDetails.value.storeGallery[index];
        return InkWell(
          onTap: () async {
            // if (await Permission.photos.request().isGranted) {}

            // ignore: deprecated_member_use
            var arr = List<String>();
            for (StoreGallery temp
                in _storeDetailController.resturantDetails.value.storeGallery) {
              arr.add(temp.storeGalleryImagePath);
            }
            /*ImageViewer.showImageSlider(
                images: arr,
                startingPosition: index,
              );*/
          },
          child: categoryShell(index),
        );
      },
    );
  }

  Widget categoryShell(int index) {
    return Container(
        height: 100,
        width: 100,
        child: InkWell(
          onTap: () {
            //_storeDetailController.pageController.jumpToPage(index);
            _storeDetailController.pageController =
                PageController(initialPage: index);
            Get.to(() => ImageViewPhotos());
          },
          child: CachedNetworkImage(
            imageUrl: _storeDetailController.resturantDetails.value
                .storeGallery[index].storeGalleryImagePath,
            placeholder: (context, url) =>
                Image.asset("assets/images/store_default.png"),
            errorWidget: (context, url, error) => Image.asset(
              "assets/images/store_default.png",
              fit: BoxFit.cover,
            ),
            imageBuilder: (context, imageProvider) => Container(
              decoration: BoxDecoration(
                  image: DecorationImage(
                    image: imageProvider,
                    fit: BoxFit.cover,
                  ),
                  borderRadius: BorderRadius.circular(15),
                  color: Colors.transparent.withOpacity(0.2)),
            ),
          ),
        ));
  }
}

class ImageViewPhotos extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    ResturantController _storeDetailController = Get.put(ResturantController());

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          Positioned(
            child: Center(
              child: Container(
                alignment: Alignment.center,
                height: 250,
                child: PageView.builder(
                  itemCount: _storeDetailController
                      .resturantDetails.value.storeGallery.length,
                  controller: _storeDetailController.pageController,
                  itemBuilder: (context, index) {
                    return Container(
                      decoration: BoxDecoration(
                          image: DecorationImage(
                              image: NetworkImage(_storeDetailController
                                  .resturantDetails
                                  .value
                                  .storeGallery[index]
                                  .storeGalleryImagePath),
                              fit: BoxFit.cover)),
                    );
                  },
                ),
              ),
            ),
          ),
          Positioned(
            top: 50,
            child: Container(
              child: IconButton(
                  onPressed: () {
                    Get.back();
                  },
                  icon: Icon(
                    Icons.close,
                    color: Colors.white,
                  )),
            ),
          ),
        ],
      ),
    );
  }
}
