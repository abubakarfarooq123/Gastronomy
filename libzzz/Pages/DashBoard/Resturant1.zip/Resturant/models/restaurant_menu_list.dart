// To parse this JSON data, do
//
//     final restaurantMenuList = restaurantMenuListFromJson(jsonString);

import 'dart:convert';

RestaurantMenuList restaurantMenuListFromJson(String str) =>
    RestaurantMenuList.fromJson(json.decode(str));

String restaurantMenuListToJson(RestaurantMenuList data) =>
    json.encode(data.toJson());

class RestaurantMenuList {
  RestaurantMenuList({
    this.responseCode,
    this.responseText,
    this.responseData,
  });

  int responseCode;
  String responseText;
  List<ResponseDatum> responseData;

  factory RestaurantMenuList.fromJson(Map<String, dynamic> json) =>
      RestaurantMenuList(
        responseCode: json["ResponseCode"],
        responseText: json["ResponseText"],
        responseData: List<ResponseDatum>.from(
            json["ResponseData"].map((x) => ResponseDatum.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "ResponseCode": responseCode,
        "ResponseText": responseText,
        "ResponseData": List<dynamic>.from(responseData.map((x) => x.toJson())),
      };
}

class ResponseDatum {
  ResponseDatum({
    this.id,
    this.storeId,
    this.description,
    this.itemName,
    this.price,
    this.discountType,
    this.discount,
    this.isPopular,
    this.image,
    this.rating,
    this.variants,
    this.menuImagePath,
    this.minPrice,
  });

  int id;
  int storeId;
  String description;
  String itemName;
  String price;
  String discountType;
  int discount;
  String isPopular;
  String image;
  String rating;
  List<Variant> variants;
  String menuImagePath;
  String minPrice;

  factory ResponseDatum.fromJson(Map<String, dynamic> json) => ResponseDatum(
        id: json["id"],
        storeId: json["store_id"],
        description: json["description"],
        itemName: json["item_name"],
        price: json["price"],
        discountType: json["discount_type"],
        discount: json["discount"] == null ? null : json["discount"],
        isPopular: json["is_popular"],
        image: json["image"],
        rating: json["rating"],
        variants: List<Variant>.from(
            json["variants"].map((x) => Variant.fromJson(x))),
        menuImagePath: json["menu_image_path"],
        minPrice: json["min_price"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "store_id": storeId,
        "description": description,
        "item_name": itemName,
        "price": price,
        "discount_type": discountType,
        "discount": discount == null ? null : discount,
        "is_popular": isPopular,
        "image": image,
        "rating": rating,
        "variants": List<dynamic>.from(variants.map((x) => x.toJson())),
        "menu_image_path": menuImagePath,
        "min_price": minPrice,
      };
}

class Variant {
  Variant({
    this.id,
    this.storeId,
    this.menuId,
    this.name,
    this.price,
    this.image,
    this.status,
    this.createdAt,
    this.updatedAt,
    this.deletedAt,
    this.finalPrice,
    this.fullImagePath,
  });

  int id;
  int storeId;
  int menuId;
  String name;
  double price;
  String image;
  String status;
  DateTime createdAt;
  DateTime updatedAt;
  dynamic deletedAt;
  String finalPrice;
  String fullImagePath;

  factory Variant.fromJson(Map<String, dynamic> json) => Variant(
        id: json["id"],
        storeId: json["store_id"],
        menuId: json["menu_id"],
        name: json["name"] == null ? null : json["name"],
        price: json["price"].toDouble(),
        image: json["image"] == null ? null : json["image"],
        status: json["status"],
        createdAt: DateTime.parse(json["created_at"]),
        updatedAt: DateTime.parse(json["updated_at"]),
        deletedAt: json["deleted_at"],
        finalPrice: json["final_price"],
        fullImagePath:
            json["full_image_path"] == null ? null : json["full_image_path"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "store_id": storeId,
        "menu_id": menuId,
        "name": name == null ? null : name,
        "price": price,
        "image": image == null ? null : image,
        "status": status,
        "created_at": createdAt.toIso8601String(),
        "updated_at": updatedAt.toIso8601String(),
        "deleted_at": deletedAt,
        "final_price": finalPrice,
        "full_image_path": fullImagePath == null ? null : fullImagePath,
      };
}
