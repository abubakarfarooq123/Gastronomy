class Message {

  DateTime time;
  String content;
  bool isSender;
  Message({ this.time, this.content, this.isSender});
}