import 'package:get/get.dart';

RxDouble totalPrice = 0.0.obs;
RxDouble deliveryCharges = 0.0.obs;
